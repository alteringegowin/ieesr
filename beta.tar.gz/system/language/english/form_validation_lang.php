<?php
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.2.4 or newer
 *
 * NOTICE OF LICENSE
 * 
 * Licensed under the Open Software License version 3.0
 * 
 * This source file is subject to the Open Software License (OSL 3.0) that is
 * bundled with this package in the files license.txt / license.rst.  It is
 * also available through the world wide web at this URL:
 * http://opensource.org/licenses/OSL-3.0
 * If you did not receive a copy of the license and are unable to obtain it
 * through the world wide web, please send an email to
 * licensing@ellislab.com so we can send you a copy immediately.
 *
 * @package		CodeIgniter
 * @author		EllisLab Dev Team
 * @copyright	Copyright (c) 2008 - 2012, EllisLab, Inc. (http://ellislab.com/)
 * @license		http://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

$lang['required']				= "The %s field is required.";
$lang['isset']					= "The %s field must have a value.";
$lang['valid_email']			= "The %s field must contain a valid email address.";
$lang['valid_emails']			= "The %s field must contain all valid email addresses.";
$lang['valid_url']				= "The %s field must contain a valid URL.";
$lang['valid_ip']				= "The %s field must contain a valid IP.";
$lang['min_length']				= "The %s field must be at least %s characters in length.";
$lang['max_length']				= "The %s field cannot exceed %s characters in length.";
$lang['exact_length']			= "The %s field must be exactly %s characters in length.";
$lang['alpha']					= "The %s field may only contain alphabetical characters.";
$lang['alpha_numeric']			= "The %s field may only contain alpha-numeric characters.";
$lang['alpha_dash']				= "The %s field may only contain alpha-numeric characters, underscores, and dashes.";
$lang['numeric']				= "The %s field must contain only numbers.";
$lang['is_numeric']				= "The %s field must contain only numeric characters.";
$lang['integer']				= "The %s field must contain an integer.";
$lang['regex_match']			= "The %s field is not in the correct format.";
$lang['matches']				= "The %s field does not match the %s field.";
$lang['is_unique'] 				= "The %s field must contain a unique value.";
$lang['is_natural']				= "The %s field must contain only positive numbers.";
$lang['is_natural_no_zero']		= "The %s field must contain a number greater than zero.";
$lang['decimal']				= "The %s field must contain a decimal number.";
$lang['less_than']				= "The %s field must contain a number less than %s.";
$lang['less_than_equal_to']		= "The %s field must contain a number less than or equal to %s.";
$lang['greater_than']			= "The %s field must contain a number greater than %s.";
$lang['greater_than_equal_to']	= "The %s field must contain a number greater than or equal to %s.";


/* End of file form_validation_lang.php */
/* Location: ./system/language/english/form_validation_lang.php */
