<div style="width:400px;text-align:center">

	<img src="img/icons/rice-cooker.png" />
	<hr />
	<div class="alert alert-info">
		<p>Alat untuk memasak nasi secara otomatis dengan energi listrik. </p>
	</div>
</div>