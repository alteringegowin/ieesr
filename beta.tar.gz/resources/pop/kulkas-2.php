<div style="width:400px;text-align:center">

	<img src="img/icons/kulkas-2.png" />
	<hr />
	<div class="alert alert-info">
		<p><strong>Pemakaian Kulkas 300 - 500 liter </strong> : Lemari es dua pintu (kapasitas 210 liter - 230 liter atau 300 liter - 700 liter), ukuran tinggi 170cm, panjang 70cm, lebar 70cm
		</p>
	</div>
</div>