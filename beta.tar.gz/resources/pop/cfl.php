<div style="width:400px;text-align:center">

	<img src="img/icons/neon-CFL.png" />
	<hr />
	<div class="alert alert-info">
		<p><strong>Neon / CFL </strong> :  Lampu neon merupakan lampu hemat energi yang digunakan untuk menggantikan lampu pijar. Lampu neon membutuhkan daya listrik yang lebih sedikit dibandingkan dengan lampu pijar, dengan menggunakan lampu neon kita bisa menghemat energi 80%, mengurangi emisi gas CO2 dan mencegah global warming
</p>
	</div>
</div>