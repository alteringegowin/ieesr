<div style="width:400px;text-align:center">

	<img src="img/icons/freezer-2.png" />
	<hr />
	<div class="alert alert-info">
		<p>Freezer (pendingin daging / es krim) : Tempat / ruangan yang dirancang dengan kondisi suhu tertentu dan digunakan untuk menyimpan berbagai macam produk (es, daging, dll) dengan tujuan mempertahankan kesegaran dan kandungan materialnya.  Ukuran 156x65x81 cm</p>
	</div>
</div>