<div style="width:400px;text-align:center">

	<img src="img/icons/microwave.png" />
	<hr />
	<div class="alert alert-info">
		<p><strong>Microwave Oven</strong> : Microwave memanaskan suatu ruangan yang sebelumnya telah diisi makanan yang hendak dimasak. Microwave biasanya menggunakan energi listrik yang diubah menjadi gelombang microwave yang sangat panas.
		</p>
	</div>
</div>