<div style="width:400px;text-align:center">

	<img src="img/icons/kulkas-3.png" />
	<hr />
	<div class="alert alert-info">
		<p><strong>Pemakaian Kulkas  500 liter </strong> : Lemari es tiga pintu ataupun pintu side by side (kapasitas 300 liter - 400 liter), ukuran tinggi 175cm, panjang 90cm, lebar 80cm</p>
	</div>
</div>