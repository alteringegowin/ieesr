<div style="width:400px;text-align:center">

	<img src="img/icons/kulkas-1.png" />
	<hr />
	<div class="alert alert-info">
		<p><strong>Pemakaian Kulkas &lt; 300 liter </strong> : Lemari es satu pintu (kapasitas 170 liter - 240 liter), ukuran tinggi 130cm, panjang 60cm, lebar 60 cm
		</p>
	</div>
</div>