 <footer>
<!--
 	<div class="footerbar footerbar-fixed">
		<ul class="nav nav-pills">
		  <li class="/"><a href=""><img src="img/icons/home-icon.png" /></a></li>
		  <li class="active"><a href="step1.php"><img src="img/icons/homegreen.png" width="40" />&nbsp;&nbsp;&nbsp;Rumah</a></li>
		  <li class=""><a href="trans.php"><img src="img/icons/delivery.png" width="40" />&nbsp;&nbsp;&nbsp;Transportasi</a></li>
		  <li class=""><a href="trash.php"><img src="img/icons/trash.png" width="40" />&nbsp;&nbsp;&nbsp;Sampah</a></li>
		  <li class=""><a href="trash.php"><img src="img/icons/task-alt.png" width="40" />&nbsp;&nbsp;&nbsp;Summary</a></li>
		</ul>
 	</div>
-->
 </footer>
 
  </body>
</html>
