<div class="alert alert-info" style="text-align:right">
  <strong>Total Emisi Penerangan:</strong> ……gram CO<sub>2</sub>ek
</div>