<div style="float: right;">
	<img src="img/paper-trash.png" height="48" width="48"  />
</div>
<h3>Sampah Kertas</h3>
<p>Lorem Ipsum Dolor sit amet</p>
<form class="form-horizontal modalForm trash">
  <fieldset>	   		
   		
   		<div class="control-group">
	      <label class="control-label" for="input01">Berapa lembar kertas yang digunakan?</label>
	      <div class="controls">
              <div class="input-append">
                <input class="span1" id="" size="16" type="text"><span class="add-on">gram</span>
              </div>
          </div>
   		</div>   		
   		
  </fieldset>
</form>