
<h2>Informasi dan Komunikasi</h2>
<hr />
<div class="well formInfo">
	<div class="imgInfo">
		<img src="img/icons/phone-charger-hi.png" width="80"  />
		<p>Charger Handphone</p>
	</div>
	<div class="imgInfo">
		<img src="img/icons/pc-desktop.png" width="60"  />
		<p>PC Desktop</p>
	</div>
	
	<div class="imgInfo">
		<img src="img/icons/laptop.png" width="50"  />
		<p>Laptop</p>
	</div>
	
	
	<div style="clear:both"></div>
</div>
<form class="form-horizontal modalForm">
	  <fieldset>	   		
	   		
	   		
	   		<div class="control-group">
		      <label class="control-label" for="input01">1. Charger Handphone</label>
		      <div class="controls">
	              <div class="input-append">
	                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
	              </div>
	          </div>
	   		</div>   	
	   		
	   		<div class="control-group">
		      <label class="control-label" for="input01">2. PC Desktop+Monitor</label>
		      <div class="controls">
	              <div class="input-append">
	                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
	              </div>
	          </div>
	   		</div>
	   		
	   		
	   		<div class="control-group">
		      <label class="control-label" for="input01">3. Laptop</label>
		      <div class="controls">
	              <div class="input-append">
	                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
	              </div>
	          </div>
	   		</div>
	   		
	   		
	  </fieldset>
	</form>
	<?php include('includes/total.php')?>