<div class="well formInfo">
	<div class="imgInfo">
		<img src="img/icons/sampah-organik.png" width="60"  />
		<p>Sampah Organik</p>
	</div>
	<div class="imgInfo">
		<img src="img/icons/kertas.png" width="38"  />
		<p>Sampah Kertas</p>
	</div>
	<div class="imgInfo">
		<img src="img/icons/botol.png" width="17"  />
		<p>Sampah Plastik</p>
	</div>
	<div style="clear:both"></div>
</div>
<div style="float: right;">
	<img src="img/organic.png" height="48" width="48"  />
</div>
<h3>Sampah Organik</h3>
<form class="form-horizontal modalForm trash">
<fieldset>	   		
   		<div class="control-group">
	      <label class="control-label" for="input01">Berapa Sampah Organik Yang Dihasilkan?</label>
	      <div class="controls">
              <div class="input-append">
                <input class="span1" id="" size="16" type="text"><span class="add-on">gram</span>
              </div>
          </div>
   		</div>
  </fieldset>
</form>
<div style="float: right;">
	<img src="img/paper-trash.png" height="48" width="48"  />
</div>
<h3>Sampah Kertas</h3>
<form class="form-horizontal modalForm trash">
  <fieldset>	   		
   		
   		<div class="control-group">
	      <label class="control-label" for="input01">Berapa lembar kertas yang digunakan?</label>
	      <div class="controls">
              <div class="input-append">
                <input class="span1" id="" size="16" type="text"><span class="add-on">gram</span>
              </div>
          </div>
   		</div>   		
   		
  </fieldset>
</form>
<h3>Sampah Plastik</h3>
<form class="form-horizontal modalForm trash">
  <fieldset>	   		   		
   		<div class="control-group">
	      <label class="control-label" for="input01">Berapa botol Air Minum Dalam Kemasan (AMDK) yang dikonsumsi?</label>
	      <div class="controls">
              <div class="input-append">
                <input class="span1" id="" size="16" type="text"><span class="add-on">gram</span>
              </div>
          </div>
   		</div>	   		
   		
  </fieldset>
</form>