<h2>Peralatan Pribadi</h2>
<hr />
<div class="well formInfo">
	<div class="imgInfo">
		<img src="img/icons/hair-dryer.png" width="70"  />
		<p>Hair Dryer</p>
	</div>
	<div class="imgInfo">
		<img src="img/icons/electric_razor.png" width="30"  />
		<p>Personal Care</p>
	</div>
	<div style="clear:both"></div>
</div>
<form class="form-horizontal modalForm">
  <fieldset>	   		
   		
   		<div class="control-group">
	      <label class="control-label" for="input01">1. Hair Dryer</label>
	      <div class="controls">
              <div class="input-append">
                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
              </div>
          </div>
   		</div>
   		
   		<div class="control-group">
	      <label class="control-label" for="input01">2. Electronic Razer / Pisau Cukur Elektronik</label>
	      <div class="controls">
              <div class="input-append">
                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
              </div>
          </div>
   		</div>
   	
   		
  </fieldset>
</form>
<?php include('includes/total.php')?>