<div style="float: right;">
	<img src="img/share.png" height="36" width="36"  />
</div>
<h3>Share</h3>
<p>Lorem Ipsum Dolor sit amet</p>
<div class="progress progress-striped">
  <div class="bar"style="width: 100%;"></div>
</div>
<div style="width:400px; margin:0 auto;">
	<a href="https://twitter.com/share" class="twitter-share-button" data-size="large" data-hashtags="carbonCalculator">Tweet</a>
	<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
</div>