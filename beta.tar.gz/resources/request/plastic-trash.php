<h3>Sampah Plastik</h3>
<p>Lorem Ipsum Dolor sit amet</p>
<form class="form-horizontal modalForm trash">
  <fieldset>	   		   		
   		<div class="control-group">
	      <label class="control-label" for="input01">Berapa botol Air Minum Dalam Kemasan (AMDK) yang dikonsumsi?</label>
	      <div class="controls">
              <div class="input-append">
                <input class="span1" id="" size="16" type="text"><span class="add-on">gram</span>
              </div>
          </div>
   		</div>	   		
   		
  </fieldset>
</form>
<?php include('includes/total.php')?>