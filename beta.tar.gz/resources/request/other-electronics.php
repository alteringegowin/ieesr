<h2>Elektronik Lainnya</h2>
<hr />
<div class="well formInfo">
	<div class="imgInfo">
		<img src="img/icons/radio.png" width="60"  />
		<p>Radio</p>
	</div>
	
	<div class="imgInfo">
		<img src="img/icons/tv.png" width="45"  />
		<p>TV LCD</p>
	</div>

	<div class="imgInfo">
		<img src="img/icons/dvd.png" width="60"  />
		<p>DVD</p>
	</div>
	
	<div class="imgInfo">
		<img src="img/icons/playstation2.png" width="70"  />
		<p>Playstation 2</p>
	</div>
	
	<div class="imgInfo">
		<img src="img/icons/xbox360.png" width="70"  />
		<p>Xbox 360</p>
	</div>
	
	<div style="clear:both"></div>
</div>
<form class="form-horizontal modalForm">
	  <fieldset>	   		
	   		
	   		<div class="control-group">
		      <label class="control-label" for="input01">1. DVD Player</label>
		      <div class="controls">
	              <div class="input-append">
	                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
	              </div>
	          </div>
	   		</div>
	   		
	   		<div class="control-group">
		      <label class="control-label" for="input01">2. Playstation PS2</label>
		      <div class="controls">
	              <div class="input-append">
	                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
	              </div>
	          </div>
	   		</div>
	   		<div class="control-group">
		      <label class="control-label" for="input01">3. Xbox 360</label>
		      <div class="controls">
	              <div class="input-append">
	                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
	              </div>
	          </div>
	   		</div>
	   		<div class="control-group">
		      <label class="control-label" for="input01">4. Tape Radio</label>
		      <div class="controls">
	              <div class="input-append">
	                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
	              </div>
	          </div>
	   		</div>
	   		<div class="control-group">
		      <label class="control-label" for="input01">5. TV (CRT 21")</label>
		      <div class="controls">
	              <div class="input-append">
	                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
	              </div>
	          </div>
	   		</div>
	   		<div class="control-group">
		      <label class="control-label" for="input01">6. TV (LCD 32")</label>
		      <div class="controls">
	              <div class="input-append">
	                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
	              </div>
	          </div>
	   		</div>
	   		
	   		
	  </fieldset>
	</form>
	<?php include('includes/total.php')?>