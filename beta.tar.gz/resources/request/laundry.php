<h2>Peralatan Rumah Tangga</h2>
<hr />
<div class="well formInfo">
	<div class="imgInfo">
		<img src="img/icons/setrika.png" height="60"  />
		<p>Setrika</p>
	</div>
	<div class="imgInfo">
		<img src="img/icons/ac.png" height="60"  />
		<p>AC (1 PK)</p>
	</div>
	<div class="imgInfo">
		<img src="img/icons/washing-machine-icon.png" alt="washing-machine-icon" width="60" />
		<p>Mesin Cuci</p>
	</div>
	<div class="imgInfo">
		<img src="img/icons/drying-machine-icon.png" width="60"  />
		<p>Mesin Pengering</p>
	</div>
	<div class="imgInfo">
		<img src="img/icons/fan.png" width="60"  />
		<p>Kipas Angin</p>
	</div>
	
	<div class="imgInfo">
		<img src="img/icons/vacuum.png" width="45"  />
		<p>Vacuum Cleaner</p>
	</div>
	
	<div style="clear:both"></div>
</div>
<form class="form-horizontal modalForm">
	  <fieldset>
		    <div class="control-group">
		      <label class="control-label" for="input01">1. Mesin Cuci</label>
		      <div class="controls">
	              <div class="input-append">
	                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
	              </div>
  	          </div>
	   		</div>
	   		
	   		<div class="control-group">
		      <label class="control-label" for="input01">2. Mesin Pengering</label>
		      <div class="controls">
	              <div class="input-append">
	                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
	              </div>
	        </div>
	   		</div>
	   		<div class="control-group">
		      <label class="control-label" for="input01">3. Setrika</label>
		      <div class="controls">
	              <div class="input-append">
	                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
	              </div>
	        </div>
	   		</div>
	   			  
	   		<div class="control-group">
		      <label class="control-label" for="input01">4. Kipas Angin</label>
		      <div class="controls">
	              <div class="input-append">
	                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
	              </div>
	          </div>
	   		</div>

	   		<div class="control-group">
		      <label class="control-label" for="input01">5. AC (1 PK)</label>
		      <div class="controls">
	              <div class="input-append">
	                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
	              </div>
	          </div>
	   		</div>
	   		
	   		<div class="control-group">
		      <label class="control-label" for="input01">6. Vacuum Cleaner</label>
		      <div class="controls">
	              <div class="input-append">
	                <input class="span1" id="" size="16" type="text"><span class="add-on">jam</span>
	              </div>
	          </div>
	   		</div>
	   			   		
	  </fieldset>
	</form>
<?php include('includes/total.php')?>