<?php include('header.php')?>

 <div id="main" class="container">

 	<header>
	 	<h1 class="title">Hitung dan Kurangi Jejak Karbon Anda</h1>
 	</header>
 	
 	<div class="mainSlider">
 		<div class="innerSlider">
	 		<h2 class="title">Apa itu Perubahan Iklim ?</h2>
	 		<div class="leftcontent">
	 			Menurut United Nations Framework Convention on Climate Change di Artikel 1, perubahan-perubahan yang terjadi pada iklim yang disebabkan oleh aktivitas manusia baik yang sifatnya langsung maupun tidak langsung terhadap perubahan komposisi atmosfer global yang berdampak pada variabel-variabel iklim dalam satu kurun waktu tertentu
	 		</div>
 		</div>
 	</div>
 	<div class="paper"></div>
 	<div class="paper2"></div>
 	<div class="buttoncontentBottom">
 		<a href="listrik.php" rel="flow" class="button green fancybox fancybox.ajax">Mulai!</a>
 		<a href="#" class="button yellow">Pelajari</a>
 	</div>
 	
 </div>
 
<?php include('footer.php')?>