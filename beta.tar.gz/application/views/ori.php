
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Aqueena Template | Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
        <link href="<?php echo $themes ?>/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo $themes ?>/css/style.css" rel="stylesheet">
        <link href="<?php echo $themes ?>/css/bootstrap-responsive.min.css" rel="stylesheet">
        <!--[if lt IE 9]>
        <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->

        <!-- Le fav and touch icons -->
        <link rel="shortcut icon" href="<?php echo $themes ?>img/favicon.ico">
        <link rel="apple-touch-icon-precomposed" href="<?php echo $themes ?>img/icon-twitter.png">
    </head>

    <body>
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </a>
                    <a class="brand" href="./dash.html">AQUEENA</a>
                    <div class="nav-collapse">
                        <ul class="nav">
                            <li class="active">
                                <a href="./dash.html">Dashboard</a>
                            </li>
                            <li>
                                <a href="#">Single Menu</a>
                            </li>
                            <li>
                                <a class="caption" data-content="And here's some amazing content. It's very engaging. right?" rel="popover"  href="#" data-original-title="A Title">
                                    Menu With Caption
                                </a>
                            </li>
                            <li class="dropdown">
                                <a data-toggle="dropdown" class="dropdown-toggle " href="#">Dropdown Menu<b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="#">Menu</a>
                                    </li>
                                    <li>
                                        <a href="#">Another Menu</a>
                                    </li>
                                    <li>
                                        <a href="#">Another Menu Too</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a href="#">Separated Menu</a>
                                    </li>
                                    <li>										
                                        <a href="#" class="caption" data-content="And here's some amazing content. It's very engaging. right?" rel="popover"  href="#" data-original-title="A Title">Separated Menu With Caption </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul class="nav pull-right">
                            <li>
                                <a href="#"><span class="badge badge-warning">23</span></a>
                            </li>
                            <li class="divider-vertical"></li>
                            <li>
                                <a>May 23, 2012</a>
                            </li>
                            <li class="divider-vertical"></li>
                            <li class="dropdown">
                                <a data-toggle="dropdown" class="dropdown-toggle " href="#">Hello New Member <b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="./account.html"><i class="icon-user"></i> Account Setting  </a>
                                    </li>
                                    <li>
                                        <a href="./change_password.html"><i class="icon-lock"></i> Change Password</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a href="./"><i class="icon-off"></i> Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row-fluid">
                <div class="span12">
                    <div class="page-header-top">
                        <div class="container">
                            <h1>Dashboard <small>include all important information here</small></h1>
                        </div>
                    </div>
                    <div class="page-header">
                        <h3>Dashboard</h3>
                    </div>
                    <div class="row-fluid">
                        <div class="span3">
                            <ul class="nav nav-tabs nav-stacked">
                                <li class="active">
                                    <a href="./dash.html" >Dashboard <span class="label label-warning pull-right">1</span></a>
                                </li>
                                <li>
                                    <a href="./table.html">Table</a>
                                </li>
                                <li>
                                    <a href="./form.html">Form</a>
                                </li>
                                <li>
                                    <a href="./tab.html">Tabular &amp; Accordion</a>
                                </li>
                            </ul>
                            <ul class="nav nav-tabs nav-stacked">

                                <li>
                                    <a href="./account.html">User Account</a>
                                </li>
                                <li>
                                    <a href="./change_password.html">Change Password</a>
                                </li>
                            </ul>
                            <form class="well form-search">
                                <input type="text" class="search-query" style="width:200px" placeholder="type and hit the enter key">
                            </form>									
                        </div>
                        <div class="span9">
                            <div class="well btn-warning">
                                <div class="row">
                                    <div class="span4">
                                        <h1>Income</h1>
                                        time by time						    			
                                    </div>
                                    <div class="span1">
                                        <h1>$25</h1>
                                        today						    			
                                    </div>
                                    <div class="span1">
                                        <h1>$550</h1>
                                        this week						    			
                                    </div>
                                    <div class="span1">
                                        <h1>$750</h1>
                                        this month						    			
                                    </div>
                                    <div class="span1">
                                        <h1>$1,200</h1>
                                        total						    			
                                    </div>
                                </div>
                            </div>
                            <h3>Chart Using Progress Bars </h3>
                            <br/>
                            <table class="table table-bordered">
                                <tr>
                                    <td width="20%">Today</td>
                                    <td>
                                        <div class="progress progress-warning">
                                            <div class="bar" style="width: 25%;">
                                                &nbsp;
                                            </div>
                                        </div></td>
                                    <td width="10%">$25.00</td>
                                </tr>
                                <tr>
                                    <td>This Week</td>
                                    <td>
                                        <div class="progress progress-danger">
                                            <div class="bar" style="width: 45%;">
                                                &nbsp;
                                            </div>
                                        </div></td>
                                    <td>$550.00</td>
                                </tr>
                                <tr>
                                    <td>This Month</td>
                                    <td>
                                        <div class="progress">
                                            <div class="bar" style="width: 65%;">
                                                &nbsp;
                                            </div>
                                        </div></td>
                                    <td>$750.00</td>
                                </tr>
                                <tr>
                                    <td>Total Income</td>
                                    <td>
                                        <div class="progress progress-success">
                                            <div class="bar" style="width: 95%;">
                                                &nbsp;
                                            </div>
                                        </div></td>
                                    <td>$1,200.00</td>
                                </tr>
                            </table>
                            <h3>Latest Transaction</h3>
                            <br/>
                            <form>
                                <table class="table table-striped table-bordered ">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Date</th>
                                            <th>Description</th>
                                            <th>Debit</th>
                                            <th>Credit</th>
                                            <th>Action</th>
                                            <th>
                                                <input type="checkbox" class="check_all"/>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td width="15%"><a href="#" class="tooltip-right" title="Put Some Information Here"><i class="icon-calendar"></i> May 1, 2012</a></td>
                                            <td><i class="icon-file"></i> Invoice #1 </td>
                                            <td>$100.00</td>
                                            <td>$50.00</td>
                                            <td width="15%">
                                                <div class="btn-group">
                                                    <a href="#" class="tooltip-top btn" title="Detail"><i class="icon-info-sign"></i></a>
                                                    <a href="#" class="tooltip-top btn" title="Edit"><i class="icon-list-alt"></i></a>
                                                </div></td>
                                            <td width="1%">
                                                <input type="checkbox"/>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>2</td>
                                            <td><a href="#" class="tooltip-left" title="Put Some Information Here"><i class="icon-calendar"></i> May 2, 2012</a></td>
                                            <td><i class="icon-file"></i> Invoice #2</td>
                                            <td>$200.00</td>
                                            <td>$40.00</td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="#" class="tooltip-top btn" title="Detail"><i class="icon-info-sign"></i></a>
                                                    <a href="#" class="tooltip-top btn" title="Edit"><i class="icon-list-alt"></i></a>
                                                </div></td>
                                            <td>
                                                <input type="checkbox"/>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td><a href="#" class="tooltip-right" title="Put Some Information Here"><i class="icon-calendar"></i> May 3, 2012</a></td>
                                            <td><i class="icon-file"></i> Invoice #3</td>
                                            <td>$300.00</td>
                                            <td>$30.00</td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="#" class="tooltip-top btn" title="Detail"><i class="icon-info-sign"></i></a>
                                                    <a href="#" class="tooltip-top btn" title="Edit"><i class="icon-list-alt"></i></a>
                                                </div></td>
                                            <td>
                                                <input type="checkbox"/>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div class="pull-right">
                                    <button type="button" class="delete btn btn-warning">
                                        <i class="icon-white icon-trash"></i> Delete Checked Box
                                    </button>
                                </div>
                                <div class="pagination">
                                    <ul>
                                        <li>
                                            <a href="#">&laquo;</a>
                                        </li>
                                        <li class="active">
                                            <a href="#">1</a>
                                        </li>
                                        <li>
                                            <a href="#">2</a>
                                        </li>
                                        <li>
                                            <a href="#">3</a>
                                        </li>
                                        <li>
                                            <a href="#">4</a>
                                        </li>
                                        <li>
                                            <a href="#">&raquo;</a>
                                        </li>
                                    </ul>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <hr/>
            <footer>
                <p>
                    Put Your Copyright Here &copy; 2012
                </p>
            </footer>

        </div>
        <script src="<?php echo $themes ?>js/jquery.js"></script>
        <script src="<?php echo $themes ?>js/bootstrap-transition.js"></script>
        <script src="<?php echo $themes ?>js/bootstrap-alert.js"></script>
        <script src="<?php echo $themes ?>js/bootstrap-modal.js"></script>
        <script src="<?php echo $themes ?>js/bootstrap-dropdown.js"></script>
        <script src="<?php echo $themes ?>js/bootstrap-scrollspy.js"></script>
        <script src="<?php echo $themes ?>js/bootstrap-tab.js"></script>
        <script src="<?php echo $themes ?>js/bootstrap-tooltip.js"></script>
        <script src="<?php echo $themes ?>js/bootstrap-popover.js"></script>
        <script src="<?php echo $themes ?>js/bootstrap-button.js"></script>
        <script src="<?php echo $themes ?>js/bootstrap-collapse.js"></script>
        <script src="<?php echo $themes ?>js/bootstrap-carousel.js"></script>
        <script src="<?php echo $themes ?>js/bootstrap-typeahead.js"></script>
        <script src="<?php echo $themes ?>js/custom.js"></script>
    </body>
</html>
