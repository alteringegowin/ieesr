
<div class="container dashboard">
    <div class="row">
        <div class="span12">
            <!-- dashboard container -->
            <div class="dashboardContainer">
                <!-- /dashboard header -->
                <div class="dashboardHeader">
                    <h3>Panduan</h3>
                    <hr />
                </div>
                <!-- /dashboard header -->

                <!-- dashboard Content -->
                <div class="dashboardContent">
                    <div class="row">
                        <div class="span3">
                            <p>Lorem Ipsum </p>
                        </div>
                    </div>
                </div>
                <!-- /dashboard content -->

            </div>
            <!-- /dashboard container -->

        </div><!--/row-->
    </div><!--/span-->
</div><!--/row-->