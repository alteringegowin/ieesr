<div class="row-fluid">
    <div class="span12">
        <div class="page-header-top">
            <div class="container">
                <h1>Dashboard <small>Everything starts here</small></h1>
            </div>
        </div>
    </div>
</div>