<div style="width:400px;text-align:center">

	<img src="<?php echo $themes?>img/icons/led.png" width="100" />
	<hr />
	<div class="alert alert-info">
		<p><strong>LED (Light Emitting Diode) </strong> :  Merupakan sejenis lampu indikator dalam perangkat elektronika, saat ini aplikasi lampu LED mulai meluas dan bahkan bisa kita temukan pada lampu emergency dan sebagainya. Led sebagai model lampu masa depan dianggap dapat menekan pemanasan global karena efisiensinya
</p>
	</div>
</div>