<div style="width:400px;text-align:center">

	<img src="<?php echo $themes?>img/icons/bulb.png" />
	<hr />
	<div class="alert alert-info">
		<p><strong>Lampu pijar </strong> : Cahaya dari lampu pijar biasanya berwarna kuning, lampu pijar juga menggunakan energi listrik yang cukup besar, dan dikategorikan sebagai lampu yang boros energi.
</p>
	</div>
</div>