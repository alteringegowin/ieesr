<?php
$config['consumer_key'] = "";
$config['consumer_key_secret'] = "";
$config['access_token'] = "";
$config['access_token_secret'] = "";
